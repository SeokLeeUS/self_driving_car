#from styx_msgs.msg import TrafficLight
import rospy
import keras
import tensorflow as tf
import numpy as np
from tensorflow.contrib.layers import flatten
from sensor_msgs.msg import Image
#from styx_msgs.msg import TrafficLightArray, TrafficLight
import cv2
from keras.models import load_model
import h5py
from keras import backend as K
#from datetime import datetime
#import os
from datetime import datetime
import os

class TLClassifier(object):
    def __init__(self):
        #TODO load classifier
        #rospy.init_node('tl_classifier')
        #sub3 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLightArray, self.traffic_cb)
        
        model = None       
        self.idx = 0
        self.light_state = 4 #unkown
        #self.lights = None
        #sub7 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLightArray, self.traffic_lights_cb)
        #sub8 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLight, self.xx_cb)
        # need to find message name for traffic light annotation 
        # I need to find out the way to classify only a message out of 3 messages. 
        #sub9 = rospy.Subscriber('vehicle/traffic_lights',TL_Sim,self.tl_state_cb)
    #rospy.spin()
    
    #def traffic_lights_cb(self, msg):
    #    self.tl_lights = msg.lights # to annotate the state
        
    #def xx_cb(self,msg):
    #    self.tl_light = msg.state

    def get_classification(self, image):
        """Determines the color of the traffic light in the image
        Args:
            image (cv::Mat): image containing the traffic light

        Returns:
            int: ID of traffic light color (specified in styx_msgs/TrafficLight)
        """
        #i = 0
        #prev_state = 4 #unknown
        
        while(self.idx < 4):
            print('camera shoot: '+ str(self.idx))
            
            if (self.idx == 0):
                #model  = load_model('model_traffic_Bosch.h5')
                #cropped_image = image[115:180, 250:380]
                #resized = cv2.resize(cropped_image, (32,32), interpolation=cv2.INTER_LINEAR)
                #image_array = np.asarray(resized)
                #labels= model.predict_classes(image_array[None, :, :, :], batch_size=1)
                bgr_image = cv2.medianBlur(image,3)
                hsv_image = cv2.cvtColor(bgr_image,cv2.COLOR_BGR2HSV)
                # Threshold the HSV image, keep only the red pixels
                lower_red_hue_range = cv2.inRange(hsv_image, (0, 100, 100), (10, 255, 255))
                upper_red_hue_range = cv2.inRange(hsv_image, (160, 100, 100), (179, 255, 255))
                
                # Combine the above two images
                red_hue_image = cv2.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0)
                red_hue_image = cv2.GaussianBlur(red_hue_image, (9, 9), 2, 2)
                
                # Use the Hough transform to detect circles in the combined threshold image
                circles_r = cv2.HoughCircles(red_hue_image, cv2.HOUGH_GRADIENT, 1, red_hue_image.shape[0] / 8.0, 100, 20, 1, 1)
                
                #print('idx: '+ str(self.idx) + ', trained_model classification by openCV:' + str(labels[0]))
                print('circles_r_detected: ' + str(len(circles_r)))
                      
                if circles_r is None or len(circles_r[0,:]) < 4:
                    #print('No circles in specified color were found! Exiting.')
                    self.light_state = 4 # unknown
                else:
                    self.light_state = 0 # red

                    
                    path = os.getcwd()
                    image_folder = path +'/sim_data'
                    timestamp = datetime.utcnow().strftime('%Y_%m_%d_%H_%M_%S_%f')[:-3]
                    image_filename = os.path.join(image_folder, timestamp+'_'+str(self.light_state)+'_'+str(len(circles_r)))
                    #print(image_filename)
                    
                    cv2.imwrite('{}.jpg'.format(image_filename),red_hue_image)
                
                #return t.state
                self.idx += 1
                #prev_state = self.state
                #return self.state
                return self.light_state
                
            elif(self.idx == 1):
                self.idx += 1
                print('no training' + str(self.idx))
                #self.state = prev_state
                return self.light_state
            elif(self.idx == 2):
                self.idx += 1
                print('no training' +str(self.idx))
                #self.state = prev_state
                return self.light_state
            elif(self.idx == 3):
                self.idx = 0
                print('idx reset')
                #self.state = prev_state
                return self.light_state
    
    
            
        #t=TrafficLight()
        #model  = load_model('model_traffic_Bosch.h5')
        #print(image.shape)
        #image = cv2.imread(image)
        ## need to cut the image 
        ## need to preprocessing
        
        ## need to process the image 1 out of 3-4 image feeds
        
        #norm_image = cv2.normalize(image, None, alpha=0, beta=1, norm_type=cv2.NORM_L1, dtype=cv2.CV_32F)
        #cv2.imwrite('tl_image.png',image)
        #cv2.imwrite('tl_image_resized.png',resized)
        
        #coords = (115,250,180,380)
        #image_obj = Image.open(image)
        #width,height = image_obj.size
        #print("width:"+str(width))
        #print("height:"+str(height))
        #cropped_image = image_obj.crop(coords)
        #width,height= cropped_image.size
        #print("croped width:"+str(width))
        #print("cropped height:"+str(height))     
        #cropped_image = image[115:180, 250:380]
        
        #cropped_image_np = np.asarray(cropped_image)
                #cropped_image.show()
        #resized = cv2.resize(cropped_image, (32,32), interpolation=cv2.INTER_LINEAR)
        
        #resized = cv2.resize(norm_image, (32,32), interpolation=cv2.INTER_LINEAR)
        
        #path = os.getcwd()
        #directory = os.path.dirname(path)
        #image_folder = directory +'/tl_detector/sim_data'
        #timestamp = datetime.utcnow().strftime('%Y_%m_%d_%H_%M_%S_%f')[:-3]
        #image_filename = os.path.join(image_folder, timestamp+'_'+str(t.state))
        #cv2.imwrite('{}.jpg'.format(image_filename),image)
        
        # assert (resized.shape == (32, 32, 3))
        #print(resized.shape)
        #K.clear_session()   
        #tf.reset_default_graph()
        #image_array = np.asarray(resized)
        #labels= model.predict_classes(image_array[None, :, :, :], batch_size=1)
        #labels = model.predict_classes(np.array([resized]))
        #print('classfier:')
        #print(labels[0])
        #print(self.lights) # test to check if state transmits
        #print(t)    
        #print('trained_model classification @tl_classifier:'+str(labels[0]))
        #print('simulation_classification:'+str(self.tl_lights[2].state))
        #print(t.state)
        


