#from styx_msgs.msg import TrafficLight
import rospy
import keras
import tensorflow as tf
import numpy as np
from tensorflow.contrib.layers import flatten
from sensor_msgs.msg import Image
#from styx_msgs.msg import TrafficLightArray, TrafficLight
import cv2
from keras.models import load_model
import h5py
from keras import backend as K
#from datetime import datetime
#import os

class TLClassifier(object):
    def __init__(self):
        #TODO load classifier
        #rospy.init_node('tl_classifier')
        #sub3 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLightArray, self.traffic_cb)
        
        model = None       
        self.idx = 0
        self.state = 4 #unkown
        #self.lights = None
        #sub7 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLightArray, self.traffic_lights_cb)
        #sub8 = rospy.Subscriber('/vehicle/traffic_lights', TrafficLight, self.xx_cb)
        # need to find message name for traffic light annotation 
        # I need to find out the way to classify only a message out of 3 messages. 
        #sub9 = rospy.Subscriber('vehicle/traffic_lights',TL_Sim,self.tl_state_cb)
    #rospy.spin()
    
    #def traffic_lights_cb(self, msg):
    #    self.tl_lights = msg.lights # to annotate the state
        
    #def xx_cb(self,msg):
    #    self.tl_light = msg.state

    def get_classification(self, image):
        """Determines the color of the traffic light in the image
        Args:
            image (cv::Mat): image containing the traffic light

        Returns:
            int: ID of traffic light color (specified in styx_msgs/TrafficLight)
        """
        #i = 0
        while(self.idx < 4):
            print('camera shoot: '+ str(self.idx))
            prev_state = 4
            if (self.idx == 0):
                model  = load_model('model_traffic_Bosch.h5')
                cropped_image = image[115:180, 250:380]
                resized = cv2.resize(cropped_image, (32,32), interpolation=cv2.INTER_LINEAR)
                image_array = np.asarray(resized)
                labels= model.predict_classes(image_array[None, :, :, :], batch_size=1)
                print('idx: '+ str(self.idx) + ', trained_model classification @tl_classifier:' + str(labels[0]))
                
                             
                
                
                if labels[0] == [1]:
                    #self.state = TrafficLight.YELLOW
                    self.state = 1 # yellow
                    #self.state = TrafficLight.RED
                elif labels[0] == [2]:
                    self.state = 0 # red 
                elif labels[0] == [3]:
                    #self.state = TrafficLight.GREEN
                    self.state = 2 # green
                elif labels[0] == [4]:
                    #self.state = TrafficLight.UNKNOWN
                    self.state = 4 # unknown
                else:
                    #self.state = TrafficLight.RED
                    self.state = 4 # unknown
                #return t.state
                self.idx += 1
                prev_state = self.state
                return self.state
            elif(self.idx == 1):
                self.idx += 1
                print('no training' + str(self.idx))
                return prev_state
            elif(self.idx == 2):
                self.idx += 1
                print('no training' +str(self.idx))
                return prev_state
            elif(self.idx == 3):
                self.idx = 0
                print('idx reset')
                return prev_state
    
    
            
        #t=TrafficLight()
        #model  = load_model('model_traffic_Bosch.h5')
        #print(image.shape)
        #image = cv2.imread(image)
        ## need to cut the image 
        ## need to preprocessing
        
        ## need to process the image 1 out of 3-4 image feeds
        
        #norm_image = cv2.normalize(image, None, alpha=0, beta=1, norm_type=cv2.NORM_L1, dtype=cv2.CV_32F)
        #cv2.imwrite('tl_image.png',image)
        #cv2.imwrite('tl_image_resized.png',resized)
        
        #coords = (115,250,180,380)
        #image_obj = Image.open(image)
        #width,height = image_obj.size
        #print("width:"+str(width))
        #print("height:"+str(height))
        #cropped_image = image_obj.crop(coords)
        #width,height= cropped_image.size
        #print("croped width:"+str(width))
        #print("cropped height:"+str(height))     
        #cropped_image = image[115:180, 250:380]
        
        #cropped_image_np = np.asarray(cropped_image)
                #cropped_image.show()
        #resized = cv2.resize(cropped_image, (32,32), interpolation=cv2.INTER_LINEAR)
        
        #resized = cv2.resize(norm_image, (32,32), interpolation=cv2.INTER_LINEAR)
        
        #path = os.getcwd()
        #directory = os.path.dirname(path)
        #image_folder = directory +'/tl_detector/sim_data'
        #timestamp = datetime.utcnow().strftime('%Y_%m_%d_%H_%M_%S_%f')[:-3]
        #image_filename = os.path.join(image_folder, timestamp+'_'+str(t.state))
        #cv2.imwrite('{}.jpg'.format(image_filename),image)
        
        # assert (resized.shape == (32, 32, 3))
        #print(resized.shape)
        #K.clear_session()   
        #tf.reset_default_graph()
        #image_array = np.asarray(resized)
        #labels= model.predict_classes(image_array[None, :, :, :], batch_size=1)
        #labels = model.predict_classes(np.array([resized]))
        #print('classfier:')
        #print(labels[0])
        #print(self.lights) # test to check if state transmits
        #print(t)    
        #print('trained_model classification @tl_classifier:'+str(labels[0]))
        #print('simulation_classification:'+str(self.tl_lights[2].state))
        #print(t.state)
        


