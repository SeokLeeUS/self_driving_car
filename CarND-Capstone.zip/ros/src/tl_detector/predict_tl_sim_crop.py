import numpy as np
import cv2
from keras.models import load_model
import h5py
from PIL import Image

model  = load_model('model_traffic_Bosch.h5')
#model = load_model('model_traffic_sim_test_cropped.h5')
#name_test = '000001_yellow.png'
#name_test = 'red_tl_test.jpg'
#name_test = 'tl_image_resized.png'
#name_test = 'tl_image.png'
name_test = 'tl_image_green_2.jpg'

coords = (130,260,180,380)
#image = cv2.imread(name_test)
#print(image.shape)

image_obj = Image.open(name_test)
width,height = image_obj.size
print("width:"+str(width))
print("height:"+str(height))
cropped_image = image_obj.crop(coords)
cropped_image.save('cropped_image.jpg')

width,height= cropped_image.size
print("croped width:"+str(width))
print("cropped height:"+str(height))    
cropped_image_np = np.asarray(cropped_image)

im = Image.fromarray(cropped_image_np)
im.save("cropped_image_np.jpg")

resized = cv2.resize(cropped_image_np, (32,32), interpolation=cv2.INTER_LINEAR)
im_resize = Image.fromarray(resized)
im_resize.save('cropped_image_resized.jpg')
#norm_image = cv2.normalize(resized, None, alpha=0, beta=1, norm_type=cv2.NORM_L1, dtype=cv2.CV_32F)
#cv2.imwrite('cropped_image_resized_normalized.jpg',norm_image)



#resized = cv2.resize(norm_image, (32,32), interpolation=cv2.INTER_LINEAR)
#assert (resized.shape == (32, 32, 3))
#labels, probabilities = model.predict(np.array([resized]), batch_size=1)
labels = model.predict_classes(np.array([resized]))
print(labels)
print(labels[0])
if labels[0]==2: #0:red, 2:green
  print('correct')
else:
  print('incorrect')

#yellow	1
#red	2
#green	3
#rest	4