import numpy as np
import cv2
from keras.models import load_model
import h5py

model  = load_model('model_traffic_Bosch.h5')
#model = load_model('model_traffic_sim_test_cropped.h5')
name_test = '000106_green.png'
#name_test = '000001_yellow.png'
#name_test = 'red_tl_test.jpg'
#name_test = 'tl_image_resized.png'
#name_test = 'tl_image.png'
image = cv2.imread(name_test)
print(image.shape)
#norm_image = cv2.normalize(image, None, alpha=0, beta=1, norm_type=cv2.NORM_L1, dtype=cv2.CV_32F)
#cropping


resized = cv2.resize(image, (32,32), interpolation=cv2.INTER_LINEAR)
assert (resized.shape == (32, 32, 3))
print(resized.shape)
#labels, probabilities = model.predict(np.array([resized]), batch_size=1)
labels = model.predict_classes(np.array([resized]))
print(labels[0])
if labels[0]==2:
  print('correct')
else:
  print('incorrect')

#yellow	1
#red	2
#green	3
#rest	4